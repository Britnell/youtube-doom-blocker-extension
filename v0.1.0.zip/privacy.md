This extension does not collect or store any personal data.

Only data stored in browser storage api is functional: the user preference of blocking youtube shorts or not. (this is a true/false value of checkbox in ui)