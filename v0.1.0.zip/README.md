# Youtube Doom Blocker

my lil browser extension to block youtube feed of video suggestions on home page (only)

## May we break the cycle

Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium enim a eos itaque nobis? Aut ratione esse earum ut eum iusto ab doloremque rerum repellat! Pariatur commodi debitis quis animi!

### publishing extensions

Publishing :
https://developer.chrome.com/docs/webstore/prepare

Console :
https://chrome.google.com/u/3/webstore/devconsole/0058ef16-be0d-42ce-bccc-ccb5611fb5eb
